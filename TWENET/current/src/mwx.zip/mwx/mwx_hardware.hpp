/* Copyright (C) 2019 Mono Wireless Inc. All Rights Reserved.    *
 * Released under MW-SLA-*J,*E (MONO WIRELESS SOFTWARE LICENSE   *
 * AGREEMENT).                                                   */

#pragma once

#include <cstdint>
namespace mwx { inline namespace L1 {
	const uint32_t HARDWARE_IO_CLOCK = 16000000UL;
}}

