/* Copyright (C) 2020 Mono Wireless Inc. All Rights Reserved.    *
 * Released under MW-SLA-*J,*E (MONO WIRELESS SOFTWARE LICENSE   *
 * AGREEMENT).                                                   */

#include "mwx_settings.hpp"

/**********************************************************************************
 * weak link defs
 **********************************************************************************/
void INTRCT_USER_vProcessInputByte(TWESERCMD_tsSerCmd_Context *pSerCmd, int16 u16Byte) {
    return;
}
