/* Copyright (C) 2019 Mono Wireless Inc. All Rights Reserved.    *
 * Released under MW-SLA-*J,*E (MONO WIRELESS SOFTWARE LICENSE   *
 * AGREEMENT).                                                   */

#include "mwx_stream.hpp"

mwx::MWX_Stream_EndLine mwx::L2::crlf;
mwx::MWX_Stream_Flush mwx::L2::flush;
