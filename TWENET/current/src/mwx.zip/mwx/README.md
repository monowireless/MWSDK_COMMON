﻿﻿# The MWX Library
Mono Wireless C++ Library for TWELITE.


The MWX library is the part of Mono Wireless TWELITE SDK ([https://mono-wireless.com/](https://mono-wireless.com/)).

MWX ライブラリは TWELITE SDK の一部です。

## License (ライセンス)
The MW-SLA-1 ([license/MW-SLA-1E.txt](license/MW-SLA-1E.txt), [license/MW-SLA-1J.txt](license/MW-SLA-1J.txt)) is applied.

モノワイヤレスソフトウェア使用許諾契約書が適用されます。

## Documents (ドキュメント)
[https://mwx.twelite.info/](https://mwx.twelite.info/)


## 修正内容
wikiページに、リリース前の修正を主に修正内容について付記します。
https://github.com/monowireless/mwx/wiki
