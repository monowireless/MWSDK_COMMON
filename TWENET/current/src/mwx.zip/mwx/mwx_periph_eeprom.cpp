/* Copyright (C) 2020 Mono Wireless Inc. All Rights Reserved.    *
 * Released under MW-SLA-*J,*E (MONO WIRELESS SOFTWARE LICENSE   *
 * AGREEMENT).                                                   */

#include "mwx_periph_eeprom.hpp"

// the instance of EEPROM
mwx::periph_eeprom mwx::L1::EEPROM;